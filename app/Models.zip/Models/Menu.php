<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Menu extends Model
{
    protected $guarded = ['id'];

    protected $casts = [
        'roles' => 'array',
    ];

    public function subMenus()
    {
        return $this->hasMany(SubMenu::class)->orderBy('order', 'asc');
    }
}